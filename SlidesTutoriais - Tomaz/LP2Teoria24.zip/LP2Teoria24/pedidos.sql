create table pedidos (
    id bigint primary key
              generated always as identity(start with 1, increment by 1),
    pdata date not null,
    valor decimal(8,2) not null,
    id_usuario bigint not null,
    foreign key (id_usuario) references usuarios (id)
);

insert into pedidos (pdata, valor, id_usuario) 
               values ('2015-01-15', 15.50, 2);
insert into pedidos (pdata, valor, id_usuario) values ('2015-02-16', 17.15, 2);
insert into pedidos (pdata, valor, id_usuario) values ('2015-03-17', 18.16, 3);
insert into pedidos (pdata, valor, id_usuario) values ('2015-04-18', 19.20, 3);
insert into pedidos (pdata, valor, id_usuario) values ('2015-05-19', 20.21, 3);
insert into pedidos (pdata, valor, id_usuario) values ('2015-06-20', 21.22, 4);