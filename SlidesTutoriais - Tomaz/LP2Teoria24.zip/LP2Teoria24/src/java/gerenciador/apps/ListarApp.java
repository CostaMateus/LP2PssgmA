package gerenciador.apps;

import gerenciador.entidades.Usuario;
import gerenciador.persistencia.ConexaoInterface;
import gerenciador.persistencia.ConexaoJavaDb;
import gerenciador.persistencia.DaoException;
import gerenciador.persistencia.UsuarioDao;
import gerenciador.persistencia.UsuarioDaoInterface;
import java.util.List;

public class ListarApp {
    public static void main(String[] args) throws DaoException {
        ConexaoInterface conexao;
        conexao = new ConexaoJavaDb("127.0.0.1", 1527, "gerenciador", "app", "app");
        UsuarioDaoInterface dao;
        dao = new UsuarioDao(conexao);
        List<Usuario> usuarios = dao.listar();
        System.out.println("Usuarios:");
        for(Usuario u: usuarios) {
            System.out.println(u.toString());
        }
    }
}
