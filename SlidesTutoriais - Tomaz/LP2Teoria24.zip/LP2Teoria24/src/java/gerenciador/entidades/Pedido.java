package gerenciador.entidades;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Pedido {
    private long id;
    private LocalDate data;
    private BigDecimal valor;
    private Usuario usuario;

    public Pedido() {
    }

    public Pedido(long id, LocalDate data, BigDecimal valor, Usuario usuario) {
        this.id = id;
        this.data = data;
        this.valor = valor;
        this.usuario = usuario;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    
}
