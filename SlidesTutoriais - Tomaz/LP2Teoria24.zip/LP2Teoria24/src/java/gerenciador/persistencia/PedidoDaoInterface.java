package gerenciador.persistencia;

import gerenciador.entidades.Pedido;
import java.util.List;

public interface PedidoDaoInterface {
    List<Pedido> buscarPorUsuario(long idUsuario) throws DaoException;
    List<Pedido> listar() throws DaoException;
}
