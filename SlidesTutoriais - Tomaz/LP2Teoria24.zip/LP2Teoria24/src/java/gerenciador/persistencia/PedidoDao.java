package gerenciador.persistencia;

import gerenciador.entidades.Pedido;
import gerenciador.entidades.Usuario;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PedidoDao implements PedidoDaoInterface {

    private ConexaoInterface conexao;
    private PreparedStatement buscarPorUsuarioStmt;
    private PreparedStatement listarPedidosStmt;
    
    public PedidoDao(ConexaoInterface conexao) throws DaoException {
        this.conexao = conexao;
        String sql;
        
        try {
            sql = "select * from pedidos where id_usuario = ?";
            buscarPorUsuarioStmt = conexao.getConnection().prepareStatement(sql);
            sql = "select pedidos.id, pedidos.pdata," +
                  "       pedidos.valor,pedidos.id_usuario,usuarios.nome, " +
                         "usuarios.idade, usuarios.apelido " +
                  "from pedidos, usuarios " +
                  "where pedidos.id_usuario = usuarios.id";
            listarPedidosStmt = conexao.getConnection().prepareStatement(sql);
        } catch (SQLException ex) {
            throw new DaoException();
        }
    }
    
    @Override
    public List<Pedido> buscarPorUsuario(long idUsuario) throws DaoException {
        List<Pedido> pedidos = new ArrayList<>();
        try {
            buscarPorUsuarioStmt.setLong(1, idUsuario);
            ResultSet result = buscarPorUsuarioStmt.executeQuery();
            while (result.next()) {
                long id = result.getLong("id");
                LocalDate data = result.getDate("pdata").toLocalDate();
                BigDecimal valor = result.getBigDecimal("valor");
                Usuario u = new Usuario();
                u.setId(idUsuario);
                Pedido p = new Pedido(id, data, valor, u);
                pedidos.add(p);
            }
        } catch (SQLException ex) {
            throw new DaoException();
        }
        return pedidos;
    }
    
    @Override
    public List<Pedido> listar() throws DaoException {
        List<Pedido> pedidos = new ArrayList<>();
        try {
            ResultSet result = listarPedidosStmt.executeQuery();
            while (result.next()) {
                long id = result.getLong("id");
                LocalDate data = result.getDate("pdata").toLocalDate();
                BigDecimal valor = result.getBigDecimal("valor");
                long idUsuario = result.getLong("id_usuario");
                String nome = result.getString("nome");
                int idade = result.getInt("idade");
                String apelido = result.getString("apelido");
                
                Usuario u = new Usuario(idUsuario, nome, idade, apelido);
                Pedido p = new Pedido(id, data, valor, u);
                
                pedidos.add(p);
            }
        } catch (SQLException ex) {
            throw new DaoException();
        }
        return pedidos;
    }
    
}
