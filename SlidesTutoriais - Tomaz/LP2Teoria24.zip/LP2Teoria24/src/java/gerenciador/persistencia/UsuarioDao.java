package gerenciador.persistencia;

import gerenciador.entidades.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDao implements UsuarioDaoInterface {

    private ConexaoInterface conexao;
    private PreparedStatement inserirStatement;
    private PreparedStatement atualizarStatement;
    private PreparedStatement listarStatement;
    private PreparedStatement apagarStatement;
    private PreparedStatement buscarStatement;

    public UsuarioDao(ConexaoInterface conexao) throws DaoException {
        this.conexao = conexao;
        String sql;
        try {
            sql = "insert into usuarios (nome, idade, apelido) values (?,?,?)";
            inserirStatement = conexao.getConnection().prepareStatement(sql);
            sql = "update usuarios set nome=?, idade=?, apelido=? where id=?";
            atualizarStatement = conexao.getConnection().prepareStatement(sql);
            sql = "select * from usuarios";
            listarStatement = conexao.getConnection().prepareStatement(sql);
            sql = "delete from usuarios where id=?";
            apagarStatement = conexao.getConnection().prepareStatement(sql);
            sql = "select * from usuarios where id=?";
            buscarStatement = conexao.getConnection().prepareStatement(sql);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new DaoException();
        }
    }
    
    @Override
    public void inserir(Usuario usuario) throws DaoException {
        try {
            inserirStatement.setString(1, usuario.getNome());
            inserirStatement.setInt(2, usuario.getIdade());
            inserirStatement.setString(3, usuario.getApelido());
            inserirStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new DaoException();
        }
        
    }

    @Override
    public void atualizar(Usuario usuario) throws DaoException {
        try {
            atualizarStatement.setString(1, usuario.getNome());
            atualizarStatement.setInt(2, usuario.getIdade());
            atualizarStatement.setString(3, usuario.getApelido());
            atualizarStatement.setLong(4, usuario.getId());
            atualizarStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new DaoException();
        }
    }

    @Override
    public List<Usuario> listar() throws DaoException {
        List<Usuario> usuarios = new ArrayList<>();
        try {
            ResultSet result = listarStatement.executeQuery();
            while(result.next()) {
                long id = result.getLong("id");
                String nome = result.getString("nome");
                int idade = result.getInt("idade");
                String apelido = result.getString("apelido");
                Usuario u = new Usuario(id, nome, idade, apelido);
                usuarios.add(u);
            }
        } catch (SQLException ex) {
            throw new DaoException();
        }
        return usuarios;
    }

    @Override
    public void apagar(Usuario usuario) throws DaoException {
        try {
            apagarStatement.setLong(1, usuario.getId());
            apagarStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new DaoException();
        }    
    }

    @Override
    public Usuario buscar(long id) throws DaoException {
        Usuario usuario = null;
        try {
            buscarStatement.setLong(1, id);
            ResultSet result = buscarStatement.executeQuery();
            if (result.next()) {
                String nome = result.getString("nome");
                int idade = result.getInt("idade");
                String apelido = result.getString("apelido");
                usuario = new Usuario(id, nome, idade, apelido);
            }
        } catch (SQLException ex) {
            throw new DaoException();
        }        
        return usuario;
    }
    
}
