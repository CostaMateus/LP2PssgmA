package gerenciador.controle;

import gerenciador.entidades.Usuario;
import gerenciador.persistencia.ConexaoInterface;
import gerenciador.persistencia.DaoException;
import gerenciador.persistencia.UsuarioDaoInterface;
import gerenciador.servlets.utils.SessionUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class ConfirmarRemocaoController implements ControllerInterface {

    private long id;
    private String pagina;
    private HttpServletRequest request;
    
    @Override
    public void init(HttpServletRequest request) {
        String sId = request.getParameter("id");
        id = Long.parseLong(sId);
        pagina = "apagar_usuario.jsp";
        this.request = request;
    }
    
    @Override
    public void execute() {
        try {
            HttpSession session = request.getSession();
            ConexaoInterface conexao;
            conexao = SessionUtils.getConexao(session);
            UsuarioDaoInterface dao;
            dao = SessionUtils.getUsuarioDao(session, conexao);
            Usuario u = dao.buscar(id);
            request.setAttribute("usuario", u);
        } catch (DaoException ex) {
            pagina = "erro.jsp";
        }
    }

    @Override
    public String getReturnPage() {
       return this.pagina;
    }

    @Override
    public ReturnType getReturnType() {
        return ReturnType.FORWARD;
    }
    
}
