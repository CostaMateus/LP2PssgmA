package gerenciador.controle;

import static gerenciador.controle.ControllerInterface.ReturnType.FORWARD;
import gerenciador.entidades.Pedido;
import gerenciador.entidades.Usuario;
import gerenciador.persistencia.ConexaoInterface;
import gerenciador.persistencia.DaoException;
import gerenciador.persistencia.PedidoDaoInterface;
import gerenciador.persistencia.UsuarioDaoInterface;
import gerenciador.servlets.utils.FormatadorData;
import gerenciador.servlets.utils.FormatadorReais;
import gerenciador.servlets.utils.SessionUtils;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

public class VerPedidosController
        implements ControllerInterface {

    private long idUsuario;
    private HttpServletRequest request;
    private String pagina = "ver_pedidos.jsp";

    @Override
    public void init(HttpServletRequest request) {
        String sId = request.getParameter("id");
        idUsuario = Long.parseLong(sId);
        this.request = request;
    }

    @Override
    public void execute() {
        ConexaoInterface conexao;
        conexao = SessionUtils.getConexao(request.getSession());
        PedidoDaoInterface pedidoDao;
        UsuarioDaoInterface usuarioDao;
        try {
            pedidoDao = SessionUtils.getPedidoDao(request.getSession(), conexao);
            usuarioDao = SessionUtils.getUsuarioDao(request.getSession(), conexao);
            
            Usuario usuario = usuarioDao.buscar(idUsuario);
            
            List<Pedido> pedidos;
            pedidos = pedidoDao.buscarPorUsuario(idUsuario);
            
            usuario.setPedidos(pedidos);
            
            request.setAttribute("usuario", usuario);
            
            FormatadorData formatadorData;
            formatadorData = new FormatadorData("dd/MM/yyyy");
            request.setAttribute("formatadorData", formatadorData);
            
            FormatadorReais formatadorReais;
            formatadorReais = new FormatadorReais();
            request.setAttribute("formatadorReais", formatadorReais);
        } catch (DaoException ex) {
            pagina = "erro.jsp";
        }
    }

    @Override
    public String getReturnPage() {
        return pagina;
    }

    @Override
    public ReturnType getReturnType() {
        return FORWARD;
    }

}
