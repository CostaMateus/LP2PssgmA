package gerenciador.controle;

import gerenciador.entidades.Pedido;
import gerenciador.persistencia.ConexaoInterface;
import gerenciador.persistencia.DaoException;
import gerenciador.persistencia.PedidoDaoInterface;
import gerenciador.servlets.utils.SessionUtils;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class ListarPedidosController 
                implements ControllerInterface {
    private HttpSession session;
    private String pagina;
    private HttpServletRequest request;
    
    @Override
    public void init(HttpServletRequest request) {
        session = request.getSession();
        pagina = "lista_pedidos.jsp";
        this.request = request;
    }

    @Override
    public void execute() {
        try {
            ConexaoInterface conexao = SessionUtils.getConexao(session);
            PedidoDaoInterface dao = SessionUtils.getPedidoDao(session, conexao);
            List<Pedido> lista;
            lista = dao.listar();
            request.setAttribute("pedidos", lista);
            
            request.setAttribute("formatadorData", SessionUtils.getFormatadorData(session));
            request.setAttribute("formatadorReais", SessionUtils.getFormatadorReais(session));
        } catch (DaoException ex) {
            pagina = "erro.jsp";
        }
    }

    @Override
    public String getReturnPage() {
        return this.pagina;
    }

    @Override
    public ReturnType getReturnType() {
        return ReturnType.FORWARD;
    }
        
}
