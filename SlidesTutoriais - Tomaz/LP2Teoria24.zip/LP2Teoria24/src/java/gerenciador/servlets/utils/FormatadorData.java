package gerenciador.servlets.utils;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

public class FormatadorData extends SimpleDateFormat {
    public FormatadorData(String format) {
        super(format);
    }
    public String format(LocalDate data) {
        return super.format(Date.valueOf(data));
    }
}
