/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gerenciador.servlets.utils;

import gerenciador.persistencia.ConexaoInterface;
import gerenciador.persistencia.ConexaoJavaDb;
import gerenciador.persistencia.DaoException;
import gerenciador.persistencia.PedidoDao;
import gerenciador.persistencia.PedidoDaoInterface;
import gerenciador.persistencia.UsuarioDao;
import gerenciador.persistencia.UsuarioDaoInterface;
import javax.servlet.http.HttpSession;

public class SessionUtils {

    public static ConexaoInterface getConexao(HttpSession session) {
        ConexaoInterface conexao;
        conexao = (ConexaoInterface) session.getAttribute("conexaoSessao");
        if (conexao == null) {
            conexao = new ConexaoJavaDb("localhost", 1527,
                    "gerenciador", "app", "app");
            session.setAttribute("conexaoSessao", conexao);
        }
        return conexao;
    }

    public static UsuarioDaoInterface getUsuarioDao(HttpSession session, ConexaoInterface conexao) throws DaoException {
        UsuarioDaoInterface dao;
        dao = (UsuarioDaoInterface) session.getAttribute("usuarioDaoSessao");
        if (dao == null) {
            dao = new UsuarioDao(conexao);
            session.setAttribute("usuarioDaoSessao", dao);
        }
        return dao;
    }

    public static PedidoDaoInterface getPedidoDao(HttpSession session, ConexaoInterface conexao) throws DaoException {
        PedidoDaoInterface dao;
        dao = (PedidoDaoInterface) session.getAttribute("pedidoDaoSessao");
        if (dao == null) {
            dao = new PedidoDao(conexao);
            session.setAttribute("pedidoDaoSessao", dao);
        }
        return dao;
    }
    
    public static FormatadorData getFormatadorData(HttpSession session) {
        FormatadorData formatador;
        formatador = (FormatadorData) session.getAttribute("formatadorData");
        if (formatador == null) {
            formatador = new FormatadorData("dd/MM/yyyy");
            session.setAttribute("formatadorData", formatador);
        }
        return formatador;
    }
    
    public static FormatadorReais getFormatadorReais(HttpSession session) {
        FormatadorReais formatador;
        formatador = (FormatadorReais) session.getAttribute("formatadorReais");
        if (formatador == null) {
            formatador = new FormatadorReais();
            session.setAttribute("formatadorReais", formatador);
        }
        return formatador;       
    }
}
