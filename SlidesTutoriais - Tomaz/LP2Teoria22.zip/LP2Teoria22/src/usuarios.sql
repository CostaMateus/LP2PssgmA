create table usuarios (
    id bigint primary key
              generated always as identity(start with 1, increment by 1),
    nome varchar(200) not null,
    idade int not null,
    apelido varchar(100) not null
);

insert into usuarios (nome, idade, apelido)
       values ('Pedro Pires', 20, 'Pires');
insert into usuarios (nome, idade, apelido)
       values ('Ver�nica', 18, 'V�');
insert into usuarios (nome, idade, apelido)
       values ('Jo�o Matos', 22, 'John');

select * from usuarios;