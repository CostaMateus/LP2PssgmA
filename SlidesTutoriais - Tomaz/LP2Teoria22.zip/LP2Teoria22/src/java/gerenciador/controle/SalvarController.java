package gerenciador.controle;

import gerenciador.entidades.Usuario;
import gerenciador.persistencia.ConexaoInterface;
import gerenciador.persistencia.DaoException;
import gerenciador.persistencia.UsuarioDaoInterface;
import gerenciador.servlets.utils.SessionUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SalvarController implements ControllerInterface {

    private HttpServletRequest request;
    private long id;
    private String nome;
    private String apelido;
    private int idade;
    private String pagina;
    
    @Override
    public void init(HttpServletRequest request) {
        String sId = request.getParameter("u_id");
        id = Long.parseLong(sId);
        nome = request.getParameter("u_nome");
        String sIdade = request.getParameter("u_idade");
        idade = Integer.parseInt(sIdade);
        apelido = request.getParameter("u_apelido");
        pagina = "FrontControllerServlet?controle=listar";
        this.request = request;
    }

    @Override
    public void execute() {
        try {
            HttpSession session = request.getSession();
            ConexaoInterface conexao;
            conexao = SessionUtils.getConexao(session);
            UsuarioDaoInterface dao;
            dao = SessionUtils.getUsuarioDao(session, conexao);
            Usuario u = new Usuario(id, nome, idade, apelido);
            dao.atualizar(u);
        } catch (DaoException ex) {
            pagina = "erro.jsp";
        }
    }

    @Override
    public String getReturnPage() {
        return pagina;
    }

    @Override
    public ReturnType getReturnType() {
        return ReturnType.REDIRECT;
    }

}
