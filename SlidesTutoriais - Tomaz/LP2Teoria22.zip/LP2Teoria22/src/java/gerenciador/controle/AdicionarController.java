package gerenciador.controle;

import gerenciador.entidades.Usuario;
import gerenciador.persistencia.ConexaoInterface;
import gerenciador.persistencia.DaoException;
import gerenciador.persistencia.UsuarioDaoInterface;
import gerenciador.servlets.utils.SessionUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class AdicionarController implements ControllerInterface {

    private String nome;
    private int idade;
    private String apelido;
    private String pagina;
    private HttpServletRequest request;
    
    @Override
    public void init(HttpServletRequest request) {
        nome = request.getParameter("nome");
        String sIdade = request.getParameter("idade");
        idade = Integer.parseInt(sIdade);
        apelido = request.getParameter("apelido");
        pagina = "adicionar_usuario.html";
        this.request = request;
    }

    @Override
    public void execute() {
        Usuario u = new Usuario(0, nome, idade, apelido);
        try {
            HttpSession session = request.getSession();
            ConexaoInterface conexao;
            conexao = SessionUtils.getConexao(session);
            UsuarioDaoInterface dao;
            dao = SessionUtils.getUsuarioDao(session, conexao);
            dao.inserir(u);
        } catch (DaoException ex) {
            pagina = "erro.jsp";
        }
    }

    @Override
    public String getReturnPage() {
        return pagina;
    }

    @Override
    public ReturnType getReturnType() {
        return ReturnType.REDIRECT;
    }

}
