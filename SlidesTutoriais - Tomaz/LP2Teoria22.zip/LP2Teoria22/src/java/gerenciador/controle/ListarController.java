package gerenciador.controle;

import gerenciador.entidades.Usuario;
import gerenciador.persistencia.ConexaoInterface;
import gerenciador.persistencia.DaoException;
import gerenciador.persistencia.UsuarioDaoInterface;
import gerenciador.servlets.utils.SessionUtils;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class ListarController implements ControllerInterface {
    private HttpSession session;
    private String pagina;
    private HttpServletRequest request;
    
    @Override
    public void init(HttpServletRequest request) {
        session = request.getSession();
        pagina = "lista_usuarios.jsp";
        this.request = request;
    }

    @Override
    public void execute() {
        try {
            ConexaoInterface conexao = SessionUtils.getConexao(session);
            UsuarioDaoInterface dao = SessionUtils.getUsuarioDao(session, conexao);
            List<Usuario> lista;
            lista = dao.listar();
            request.setAttribute("lista_usuarios", lista);
        } catch (DaoException ex) {
            pagina = "erro.jsp";
        }
    }

    @Override
    public String getReturnPage() {
        return this.pagina;
    }

    @Override
    public ReturnType getReturnType() {
        return ReturnType.FORWARD;
    }
    
}
