package gerenciador.persistencia;

public class DaoException extends Exception {}
