package gerenciador.persistencia;

import gerenciador.entidades.Usuario;
import java.util.List;

public interface UsuarioDaoInterface {
    void inserir(Usuario usuario) throws DaoException;
    void atualizar(Usuario usuario) throws DaoException;
    List<Usuario> listar() throws DaoException;
    void apagar(Usuario usuario) throws DaoException;
    Usuario buscar(long id) throws DaoException;
}
