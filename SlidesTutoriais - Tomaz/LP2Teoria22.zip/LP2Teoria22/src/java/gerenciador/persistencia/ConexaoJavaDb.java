package gerenciador.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexaoJavaDb implements ConexaoInterface {

    private String host;
    private int porta;
    private String nomeBase;
    private String usuario;
    private String senha;
    private Connection connection = null;

    public ConexaoJavaDb(String host, int porta, String nomeBase, String usuario, String senha) {
        this.host = host;
        this.porta = porta;
        this.nomeBase = nomeBase;
        this.usuario = usuario;
        this.senha = senha;
    }

    @Override
    public Connection getConnection() throws DaoException {
        if (connection == null) {
            String url = "jdbc:derby://" + host + ":" + porta + "/" + nomeBase;
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
                connection = DriverManager.getConnection(url, usuario, senha);
            } catch (ClassNotFoundException ex) {
                throw new DaoException();
            } catch (SQLException ex) {
                throw new DaoException();
            }
        }
        return connection;
    }
}
