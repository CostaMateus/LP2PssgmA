package gerenciador.entidades;

import java.io.Serializable;

public class Usuario implements Serializable {
    private long id;
    private String nome;
    private int idade;
    private String apelido;

    public Usuario() {
    }

    public Usuario(long id, String nome, int idade, String apelido) {
        this.id = id;
        this.nome = nome;
        this.idade = idade;
        this.apelido = apelido;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
    
    @Override
    public String toString() {
        return id + ":" + nome + ":" + idade + ":" + apelido;
    }
}
